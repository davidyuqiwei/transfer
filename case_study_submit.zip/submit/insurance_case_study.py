import os
import random
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.metrics import precision_score, recall_score, f1_score


def data_loader(data1_path, data2_path, data3_path):
    """
    load data
    :param data1_path: case_study_data1.xlsx
    :param data2_path: case_study_data2.xlsx
    :param data3_path: case_study_data3.csv
    :return:
    """

    label_idx, idx_label = {}, {}

    data1_df = pd.read_excel(data1_path)
    data2_df = pd.read_excel(data2_path)
    data3_df = pd.read_csv(data3_path)
    data1_df["product"] = data1_df["product"].str.split(":")

    data1_df = data1_df.explode("product")

    product_df = pd.DataFrame(data1_df["product"].value_counts())
    product_df.columns = ["cnt"]
    product_min_cnt = 50

    product_list = product_df[product_df["cnt"] >= product_min_cnt].index.tolist()

    for product in product_list:
        if product not in label_idx:
            idx_label[len(idx_label)] = product
            label_idx[product] = len(label_idx)

    data1_df = data1_df.join(product_df, on="product")

    data1_df = data1_df[data1_df["cnt"] >= product_min_cnt]

    data2_df = data2_df.drop(["Unnamed: 6", "Unnamed: 7", "Unnamed: 8", "Unnamed: 9"], 1)
    data1_df = data1_df.merge(data2_df, left_on="policy_id", right_on="policy_id", how="left")
    data1_df = data1_df.merge(data3_df, left_on="policy_owner_id", right_on="owner_or_insured_id", how="left")

    product_cnt = data1_df["product"].value_counts()
    product_cnt = pd.DataFrame(product_cnt)
    product_cnt.columns = ["cnt"]
    product_cnt = product_cnt.sort_values("cnt", ascending=False)
    product_p = (product_cnt / product_cnt.sum())
    label_p = {}
    for row in product_p.iterrows():
        label_p[label_idx[row[0]]] = row[1]["cnt"]
    label_p = sorted(label_p.items(), key=lambda x: x[1])
    return data1_df, label_idx, idx_label, label_p


def feature_process(dataset):
    """
    use one-hot to encode feature
    """
    columns = ["agency_code", "agent_code", "policy_pending_status", "document_uploaded", "paid_by_echannel",
               "policy_owner_id", "policy_insured_id", "Age", "Gender", "Education_Level"]
    dataset = pd.get_dummies(dataset, columns=columns)
    df = dataset[["policy_id", "policy_pending_code"]]
    df["policy_pending_code"] = df["policy_pending_code"].str.split(":")
    df = df.explode("policy_pending_code")
    df = pd.get_dummies(df)
    df = df.groupby("policy_id").sum()
    dataset = dataset.drop("policy_pending_code", 1)
    dataset.merge(df, left_on="policy_id", right_on="policy_id", how="left")
    return dataset


def train(train_x, train_y, dev_x, dev_y, root):
    """
    train the model Lightgbm
    :param train_x: training features
    :param train_y: training labels
    :param dev_x: development features
    :param dev_y: development labels
    :param root: the root of model related file
    :return:
    """
    params = {
        'boosting': 'gbdt',
        'bagging_freq': 50,
        'bagging_fraction': 0.5,
        'feature_fraction': 0.3,
        'min_data_in_leaf': 10,
        'learning_rate': 0.015,
        'lambda_l1': 0.00001,
        'lambda_l2': 0.00001,
        'max_depth': 40,
        'num_leaves': 40,
        'objective': 'multiclass',
        'num_class': 33,
        'metric': 'multi_logloss'
    }

    train_data = lgb.Dataset(train_x, train_y)
    dev_data = lgb.Dataset(dev_x, dev_y)
    model = lgb.train(params, train_data, num_boost_round=100, valid_sets=[dev_data])
    model.save_model(os.path.join(root, "model.pt"))
    importance = model.feature_importance(importance_type="gain")
    feature_name = model.feature_name()
    feature_importance = pd.DataFrame({"feature_name": feature_name, "importance": importance})\
        .sort_values("importance", ascending=False)
    feature_importance.to_csv(os.path.join(root, "feature_importance.csv"), index=False)
    return model


def evaluate(pred_y, y):
    """
    evaluate the performance of model
    :param pred_y: the predicted label
    :param y: the ground truth
    """
    micro_precision = round(precision_score(pred_y, y, average="micro"), 4)
    micro_recall = round(recall_score(pred_y, y, average="micro"), 4)
    micro_f1 = round(f1_score(pred_y, y, average="micro"), 4)
    macro_precision = round(precision_score(pred_y, y, average="macro"), 4)
    macro_recall = round(recall_score(pred_y, y, average="macro"), 4)
    macro_f1 = round(f1_score(pred_y, y, average="macro"), 4)
    print(micro_precision, micro_recall, micro_f1)
    print(macro_precision, macro_recall, macro_f1)


def random_model(x, class_num, p=None):
    """
    train the model Lightgbm
    :param x: test data
    :param class_num: the number of class
    :param p: the random probability
    :return:
    """
    pred_y = []
    if p is None:
        p = 1 / class_num
        for _ in range(len(x)):
            idx = random.random() // p
            pred_y.append(idx)
    else:
        for _ in range(len(x)):
            rand_val = random.random() * p[-1][1]
            for i in range(len(p)):
                if rand_val <= p[i][1]:
                    pred_y.append(p[i][0])
                    break
    return pred_y


def popular_model(x, popular):
    pred_y = []
    for _ in range(len(x)):
        pred_y.append(popular)
    return pred_y


def main():
    """
    the main function
    """
    root = "D:/case study/"

    # data loading
    data1_path = os.path.join(root, "case_study_data1.xlsx")
    data2_path = os.path.join(root, "case_study_data2.xlsx")
    data3_path = os.path.join(root, "case_study_data3.csv")
    dataset, label_idx, idx_label, label_p = data_loader(data1_path, data2_path, data3_path)

    # feature precessing
    dataset = feature_process(dataset)

    # data splitting
    train_data = dataset[dataset["policy_application_date"] < "11/01/2021"]
    train_data = train_data.drop(["policy_application_date", "policy_close_date"], 1)
    dev_data = dataset[("11/01/2021" <= dataset.policy_application_date) & (dataset.policy_application_date < "12/01/2021")]
    dev_data = dev_data.drop(["policy_application_date", "policy_close_date"], 1)
    test_data = dataset["12/01/2021" <= dataset["policy_application_date"]]
    test_data = test_data.drop(["policy_application_date", "policy_close_date"], 1)

    train_x, train_y_name = train_data.drop("product", 1), train_data["product"].tolist()
    train_y = []
    for _y_name in train_y_name:
        train_y.append(label_idx[_y_name])
    dev_x, dev_y_name = dev_data.drop("product", 1), dev_data["product"].tolist()
    dev_y = []
    for _y_name in dev_y_name:
        dev_y.append(label_idx[_y_name])
    test_x, test_y_name = test_data.drop("product", 1), test_data["product"].tolist()
    test_y = []
    for _y_name in test_y_name:
        test_y.append(label_idx[_y_name])

    # random with the same probability
    pred_y = random_model(test_x, 33)
    evaluate(pred_y, test_y)

    # random with the pre-defined probability
    pred_y = random_model(test_x, 33, label_p)
    evaluate(pred_y, test_y)

    # popular
    pred_y = popular_model(test_x, label_p[-1][0])
    evaluate(pred_y, test_y)

    # lgihtgbm
    # model = train(train_x, train_y, dev_x, dev_y)
    model = lgb.Booster(model_file=os.path.join(root, "model.pt"))
    pred = model.predict(test_x)
    pred_y = []
    for p in pred:
        p = p.tolist()
        pred_y.append(p.index(max(p)))
    evaluate(pred_y, test_y)


if __name__ == '__main__':
    main()
